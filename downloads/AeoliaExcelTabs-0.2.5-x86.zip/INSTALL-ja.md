# インストール・更新・復元 — 32 ビットExcel

## 登録済みの方の更新（通常はこちら）
1. 作業を保存し、Excelをすべて通常終了します。保存確認が残る場合は先に解決し、強制終了しません。
2. 現在登録されているAeolia.Integrated.dllのフォルダーを確認します。旧版のDLL2個とVERSION.json／pair.jsonがあればそれも、別のバックアップフォルダーに保存します。配色設定は削除しません。
3. このZIPのDLL2個とVERSION.jsonを、現在と同じフォルダーへ組で配置します。片方だけ更新したり、ビット数を混ぜたりしません。ファイルが使用中なら中止します。途中で一部だけコピーできた場合はExcelを起動せず、旧DLL2個と旧VERSION.jsonへ戻してください。
   pair.jsonのある管理された導入環境では、その環境の専用更新手順を使用し、手動でDLLだけを上書きしないでください。
4. 登録済みでパスが変わらない場合は、登録テンプレートを再取り込みしません。CodeBase・LoadBehavior・その他の登録値はそのままです。
5. 普段のタスクバー等からExcelを起動し、まず空白ブックでタブ表示と新規作成・切替を確認します。外部ツールからの起動だけで完了とはしません。

内部識別子にReview／Previewが残っていても、表示名だけでDLLの新旧は判定できません。版番号とSHA256SUMS.txtを確認してください。通常起動だけで古い名前や別の登録が見える場合は、再登録・無効化設定の削除を繰り返さず状況を報告してください。

## 初めて登録する場合
対象はWindowsの現在のユーザーと、この 32 ビットExcel用の3ルートだけです。管理者実行や保護設定の変更は不要です。会社の利用ルールに従ってください。

HKEY_CURRENT_USER\Software\Classes\Aeolia.ExcelAlternate.IntegratedReview
HKEY_CURRENT_USER\Software\Classes\CLSID\{10D909B0-5A37-4E7B-956A-78429CFA4E4C}
HKEY_CURRENT_USER\Software\Microsoft\Office\Excel\Addins\Aeolia.ExcelAlternate.IntegratedReview

同じ登録が既にある場合は上書きせず、登録済み更新の手順に戻ってください。

1. DLL2個を今後も使う固定フォルダーに置き、SHA256SUMS.txtを照合します。
2. Registration.template.reg.txtのコピーを作り、2か所の __CODEBASE_URI__ を、両方とも管理DLL Aeolia.Integrated.dllの同じfile URIに置き換えます。
   例：C:\Apps\Aeolia ExcelTabs\x86\Aeolia.Integrated.dll
   → file:///C:/Apps/Aeolia%20ExcelTabs/x86/Aeolia.Integrated.dll
   URIはスラッシュを使い、空白は%20です。Native DLLのURIは記入しません。
3. 置換済みコピーを.regとして保存し、通常ユーザーのコマンドプロンプトから次を実行します。未置換のテンプレートは取り込みません。
   reg import "作成したファイル.reg" /reg:32
4. 両CodeBaseの一致と専用Addinsキーを確認します。初期LoadBehaviorは 3（自動起動ON）、CommandLineSafeは0です。
5. Excelの「ファイル→オプション→アドイン→管理:COMアドイン→設定」でAeolia Excel Tabsを確認します。初回は空白ブックまたはコピーで確認してください。

自動起動を選ぶ場合は、保存してExcelを正常終了後、専用AddinsキーのLoadBehaviorをDWORDの3にします。停止は0です。既存環境の設定は更新時に維持します。CommandLineSafeやOfficeの信頼・マクロ設定は変更しません。

## 一時無効化・撤去
COMアドイン画面のチェックを外し、必要な内容を保存して正常終了します。起動時の読込みを止める場合は専用LoadBehaviorを0にします。
完全撤去は、登録先と値がこの製品のものであることを確認し、上記3ルートをバックアップした後、その3ルートだけを削除します。親のClasses／CLSID／Addins、他ビット版のキー、他のアドイン、Office、ブック、PERSONALは削除しません。不明な登録は操作せず停止してください。

## 旧版へ戻す
Excelを正常終了し、今回のDLL2個を保管したうえで、バックアップした旧DLL2個と旧VERSION.json（存在した場合）を元と同じ場所へ戻します。旧版にVERSION.jsonがなかった場合、今回配置したVERSION.jsonも残さず退避してください。登録パス・設定を変えていない更新なら、レジストリ復元は不要です。新規登録を取り消す場合は、この製品の専用3ルートだけを撤去します。別の値や登録先へ変わっている場合は、自動的に上書きしません。
配色・枠線設定はLocalAppData/Aeolia/ExcelTabs/colors-v2.txtです。削除は不要です。個人パスを含む登録バックアップは公開しないでください。

## 今回の2画面・描画修正の確認
空白ブック2冊で、各モニターの「最大化→タブ切替→通常サイズへ復元」を確認します。別モニターに移る、表示が崩れる、保存確認が正常に扱えない場合は作業を止め、通常終了後に旧版へ戻してください。画面設定を変えて試験する必要はありません。白い瞬間が残る場合も、再現する操作と構成を記録してください。静止画だけでは瞬間的なちらつきの有無は判定できません。
AEOLIA Translator component update
1. Keep your already downloaded/extracted 0.2.0 folder. Do not delete it.
2. Close both lightweight and quality Translator windows.
3. Extract this ZIP INSIDE that existing folder. You should see:
   existing-folder/runtime/python.exe
   existing-folder/Update-software-0.3.1/Install.cmd
4. If part files were supplied separately, put ALL of them into Update-software-0.3.1.
5. Run Install.cmd. It verifies version, sizes and SHA-256 before updating.
6. Use the existing Start.cmd / Start-Quality.cmd after success.

This updater never downloads anything. No administrator rights or security-policy
change is required. Company approval for bringing/running the application still applies.
If execution is blocked by company policy, stop and ask IT; do not bypass it.
Modified or unknown files are not overwritten. The old replaced files remain under
.component-backups. Never delete the original installation or backup to resolve an error.
Hashes detect corruption, not publisher authenticity: obtain all files only from
the owner's verified homepage/release, not from arbitrary third parties.
Existing user data is not removed. Unchanged models/runtime are not re-downloaded.
There must be room for the downloaded archive, staging and backups.

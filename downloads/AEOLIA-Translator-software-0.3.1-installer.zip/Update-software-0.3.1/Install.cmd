@echo off
setlocal
if not exist "%~dp0..\runtime\python.exe" (
  echo Extract this update folder INSIDE your existing AEOLIA Translator folder.
  pause
  exit /b 1
)
"%~dp0..\runtime\python.exe" -B "%~dp0components.py" install "%~dp0AEOLIA-Translator-software-0.3.1.download.json" "%~dp0.."
if errorlevel 1 (echo Update failed. Please read the message above.) else (echo Update completed.)
pause

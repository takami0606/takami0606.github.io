"""Offline component packager/installer. No network or automatic execution."""
from __future__ import annotations
import argparse, hashlib, json, os, re, shutil, socket, stat, tempfile, time, zipfile
from pathlib import Path, PurePosixPath

SCHEMA=1
COMPONENTS={"software","light-core","quality-core"}
BLOCKED={"CON","PRN","AUX","NUL",*(f"COM{i}" for i in range(1,10)),*(f"LPT{i}" for i in range(1,10))}
def digest(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
    return h.hexdigest()
def safe_name(name):
    if not isinstance(name,str) or "\\" in name or ":" in name or name.startswith("/") or len(name)>240:
        raise ValueError("Unsafe path")
    parts=name.split("/")
    if any(not p or p in (".","..") or p.endswith(("."," ")) or any(c in p for c in '<>"|?*') or p.split(".")[0].upper() in BLOCKED for p in parts):
        raise ValueError("Unsafe path")
    return name
def within(root,name):
    safe_name(name)
    root=root.resolve()
    target=root.joinpath(*name.split("/"))
    # Reject junctions/symlinks in every existing ancestor, before resolving.
    cur=target
    while cur!=root:
        if cur.exists() or cur.is_symlink():
            s=cur.lstat()
            if stat.S_ISLNK(s.st_mode) or (getattr(s,"st_file_attributes",0)&0x400):
                raise ValueError("Links/reparse points are not supported")
        cur=cur.parent
    if root not in target.resolve().parents: raise ValueError("Path escapes target")
    return target
def allowed(component,name):
    top=name.split("/")[0]
    if top in {"logs","config","backups",".components",".component-backups"}:return False
    if component=="light-core":return top in {"models","runtime","third_party"} or name.startswith("docs/light-core/")
    if component=="quality-core":return top in {"models_quality","runtime_llama"} or name.startswith("docs/quality-core/")
    if component=="software":return top in {"app","ui","app_quality","ui_quality","docs","tests","tools"} or name in {"Start.cmd","Start-Quality.cmd","README_JA.txt","README.md","README_JA.md","README-Quality-JA.md","THIRD_PARTY_NOTICES.md"}
    return False
def write_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
def build(source,out,component,version,part_bytes=1500000000,requires=None):
    if component not in COMPONENTS or not re.fullmatch(r"[A-Za-z0-9._-]{1,60}",version):raise ValueError("Invalid component/version")
    out.mkdir(parents=True,exist_ok=True)
    files=[]
    for p in sorted(source.rglob("*")):
        if p.is_symlink() or (getattr(p.lstat(),"st_file_attributes",0)&0x400):raise ValueError("Source contains link")
        if not p.is_file():continue
        name=p.relative_to(source).as_posix(); safe_name(name)
        if not allowed(component,name):raise ValueError("Disallowed component path: "+name)
        files.append({"path":name,"bytes":p.stat().st_size,"sha256":digest(p)})
    if not files:raise ValueError("Empty component")
    manifest={"schema":SCHEMA,"component":component,"version":version,"requires":requires or {},"files":files}
    stem=f"AEOLIA-Translator-{component}-{version}"
    with tempfile.TemporaryDirectory(prefix=".pack-",dir=out) as td:
        archive=Path(td)/(stem+".zip")
        with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            z.writestr("component.json",json.dumps(manifest,ensure_ascii=False))
            for row in files:z.write(source/row["path"],"payload/"+row["path"])
        total=archive.stat().st_size; parts=[]
        with archive.open("rb") as f:
            i=1;remaining=total
            while remaining:
                name=stem+(".zip" if total<=part_bytes else f".zip.part{i:02d}")
                p=out/name
                if p.exists():raise ValueError("Output exists: "+str(p))
                size=min(part_bytes,remaining);left=size;h=hashlib.sha256()
                with p.open("wb") as part:
                    while left:
                        data=f.read(min(left,1024*1024))
                        if not data:raise OSError("Unexpected archive end")
                        part.write(data);h.update(data);left-=len(data)
                parts.append({"name":name,"bytes":size,"sha256":h.hexdigest()});i+=1;remaining-=size
        desc={"schema":SCHEMA,"component":component,"version":version,"archive_bytes":total,"archive_sha256":digest(archive),"parts":parts}
        descriptor=out/(stem+".download.json")
        if descriptor.exists():raise ValueError("Descriptor exists")
        write_json(descriptor,desc)
        return descriptor

def load_download(desc):
    d=json.loads(desc.read_text(encoding="utf-8"))
    if d.get("schema")!=SCHEMA or d.get("component") not in COMPONENTS:raise ValueError("Unknown download format")
    parts=d.get("parts",[])
    if not 1<=len(parts)<=64:raise ValueError("Invalid part count")
    seen=set()
    for row in parts:
        name=safe_name(row["name"])
        if "/" in name or name.casefold() in seen:raise ValueError("Invalid part name")
        seen.add(name.casefold())
        p=within(desc.parent,name)
        if not p.is_file() or p.stat().st_size!=row["bytes"] or digest(p)!=row["sha256"]:raise ValueError("Part missing or checksum mismatch: "+name)
    return d
def install(desc,target,check_ports=True,fail_after=None):
    target=Path(os.path.abspath(target))
    if not target.is_dir():raise ValueError("Select an existing extracted AEOLIA Translator folder")
    for p in [target,*target.parents]:
        if p.is_symlink() or getattr(p.lstat(),"st_file_attributes",0)&0x400:raise ValueError("Target uses a link/reparse point")
    lock=target/".component-update.lock"
    try:
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError:
        raise ValueError("Another update is running, or a previous update was interrupted. Keep backups and investigate the lock before retrying.")
    try:
        os.write(fd,str(os.getpid()).encode());os.close(fd)
        return _install(desc,target,check_ports,fail_after)
    finally:
        lock.unlink()
def _install(desc,target,check_ports=True,fail_after=None):
    if not target.is_dir() or not (target/"runtime/python.exe").is_file():raise ValueError("Select an existing extracted AEOLIA Translator folder")
    for p in [target,*target.parents]:
        if getattr(p.lstat(),"st_file_attributes",0)&0x400 or p.is_symlink():raise ValueError("Target uses a link/reparse point")
    d=load_download(desc)
    if check_ports:
        for port in (51231,51233,51234):
            with socket.socket() as s:
                s.settimeout(.15)
                if s.connect_ex(("127.0.0.1",port))==0:raise ValueError("Close both Translator modes before updating")
    # Only the installer metadata is written outside payload. No user data deletion.
    state_dir=target/".components"
    backup_dir=target/".component-backups"
    for p in (state_dir,backup_dir):
        if p.exists() and (p.is_symlink() or getattr(p.lstat(),"st_file_attributes",0)&0x400):raise ValueError("Unsafe metadata path")
    state={}
    if state_dir.exists():
        for p in state_dir.glob("*.json"):
            st=json.loads(p.read_text(encoding="utf-8"));state[st["component"]]=st
    # Original 0.2.0 file manifest is a trust baseline for files replaced on first update.
    baseline={}
    base=target/"FILE_MANIFEST.json"
    if base.is_file():
        b=json.loads(base.read_text(encoding="utf-8"))
        if b.get("version")!="0.2.0":raise ValueError("Unsupported original base")
        baseline={r["path"]:r["sha256"] for r in b.get("files",[])}
    for st in state.values():
        baseline.update({r["path"]:r["sha256"] for r in st["files"]+st.get("retained_files",[])})
    with tempfile.TemporaryDirectory(prefix=".aeolia-update-",dir=target) as td:
        td=Path(td);archive=td/"component.zip"
        with archive.open("wb") as out:
            for row in d["parts"]:
                with (desc.parent/row["name"]).open("rb") as f:shutil.copyfileobj(f,out,1024*1024)
        if archive.stat().st_size!=d["archive_bytes"] or digest(archive)!=d["archive_sha256"]:raise ValueError("Archive checksum mismatch")
        staged=td/"staged";staged.mkdir()
        with zipfile.ZipFile(archive) as z:
            if len(z.infolist())>10000:raise ValueError("Too many entries")
            names=set()
            for info in z.infolist():
                safe_name(info.filename)
                if info.filename.casefold() in names or (info.external_attr>>16 & 0o170000)==0o120000:raise ValueError("Duplicate path or link")
                names.add(info.filename.casefold())
            if z.getinfo("component.json").file_size>2000000:raise ValueError("Manifest too large")
            m=json.loads(z.read("component.json"))
            if m.get("schema")!=SCHEMA or m.get("component")!=d["component"] or m.get("version")!=d["version"]:raise ValueError("Manifest identity mismatch")
            if m["component"] in state:
                old=state[m["component"]]
                def ver(v):
                    match=re.match(r"^(\d+)\.(\d+)\.(\d+)",v)
                    if not match:raise ValueError("Invalid component version")
                    return tuple(map(int,match.groups()))
                if ver(m["version"])<ver(old["version"]):raise ValueError("Downgrade is not supported")
                if m["version"]==old["version"] and m["files"]!=old["files"]:raise ValueError("Same version has different contents")
            files=m["files"];expected={"component.json"};seen=set()
            for row in files:
                name=safe_name(row["path"])
                if name.casefold() in seen or not allowed(m["component"],name):raise ValueError("Invalid payload path")
                seen.add(name.casefold());expected.add("payload/"+name)
                info=z.getinfo("payload/"+name)
                if info.file_size!=row["bytes"] or row["bytes"]<0:raise ValueError("Payload size mismatch")
            if {i.filename for i in z.infolist()}!=expected:raise ValueError("Unexpected archive entry")
            needed=sum(r["bytes"] for r in files)
            if shutil.disk_usage(target).free<needed*2+10000000:raise ValueError("Not enough free space for staging and backup")
            for component,version in m.get("requires",{}).items():
                if component=="base":ok=base.is_file() and b["version"]==version
                else:ok=component in state and state[component]["version"]==version
                if not ok:raise ValueError("Missing required component: "+component+" "+version)
            proposed=dict(state);proposed[m["component"]]=m
            for dependent in proposed.values():
                for dep,version in dependent.get("requires",{}).items():
                    ok=(base.is_file() and b["version"]==version) if dep=="base" else dep in proposed and proposed[dep]["version"]==version
                    if not ok:raise ValueError("Update would break dependency of "+dependent["component"]+": "+dep+" "+version)
            expected_current={}
            for row in files:
                name=row["path"];dst=within(target,name)
                for comp,st in state.items():
                    if comp!=m["component"] and any(r["path"].casefold()==name.casefold() for r in st["files"]+st.get("retained_files",[])):raise ValueError("File belongs to another component")
                if dst.exists():
                    if not dst.is_file():raise ValueError("Destination is not a file")
                    cur=digest(dst)
                    if name.startswith("runtime/") and cur!=row["sha256"]:raise ValueError("This updater does not replace the shared Python runtime; a separately tested runtime migration is required")
                    if cur!=row["sha256"] and cur!=baseline.get(name):raise ValueError("Locally modified/unknown file; not overwritten: "+name)
                    expected_current[name]=cur
                else:
                    if name.startswith("runtime/"):raise ValueError("This updater does not add shared runtime files")
                    expected_current[name]=None
                p=within(staged,name);p.parent.mkdir(parents=True,exist_ok=True)
                with z.open("payload/"+name) as src,p.open("wb") as out:shutil.copyfileobj(src,out,1024*1024)
                if digest(p)!=row["sha256"]:raise ValueError("Payload checksum mismatch: "+name)
        stamp=time.strftime("%Y%m%d-%H%M%S")+"-"+str(time.time_ns())
        backup=backup_dir/(m["component"]+"-"+stamp)
        backup.mkdir(parents=True)
        installed=[];saved=[];applied=[]
        try:
            for row in files:
                name=row["path"];dst=within(target,name)
                current=digest(dst) if dst.is_file() else None
                if current!=expected_current[name]:raise ValueError("File changed during update; stopped: "+name)
                if current==row["sha256"]:continue
                if dst.exists():
                    bak=within(backup,name);bak.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,bak)
                was_existing=dst.exists()
                dst.parent.mkdir(parents=True,exist_ok=True)
                os.replace(within(staged,name),dst)
                (saved if was_existing else installed).append(name)
                applied.append(row)
                if fail_after is not None:
                    fail_after-=1
                    if fail_after==0:raise OSError("Injected failure")
            state_dir.mkdir(exist_ok=True)
            statefile=state_dir/(m["component"]+".json")
            if statefile.exists():shutil.copy2(statefile,backup/"previous-component.json")
            old=state.get(m["component"],{})
            current_names={r["path"].casefold() for r in m["files"]}
            m["retained_files"]=[r for r in old.get("files",[])+old.get("retained_files",[]) if r["path"].casefold() not in current_names]
            tmp=td/"new-state.json";write_json(tmp,m)
            write_json(backup/"transaction.json",{"status":"complete","component":m["component"],"version":m["version"],"replaced":saved,"created":installed})
            os.replace(tmp,statefile)
        except Exception:
            errors=[]
            for row in reversed(applied):
                name=row["path"]
                try:
                    dst=within(target,name)
                    if not dst.is_file() or digest(dst)!=row["sha256"]:raise OSError("Updated file changed externally")
                    if name in saved:shutil.copy2(within(backup,name),dst)
                    else:dst.unlink()
                except Exception as rollback_error:errors.append(name+": "+str(rollback_error))
            write_json(backup/"transaction.json",{"status":"rollback-incomplete" if errors else "rolled-back","replaced":saved,"created":installed,"errors":errors})
            if errors:raise OSError("Update failed and some rollback steps need attention. Preserve backup: "+str(backup)+"; "+"; ".join(errors))
            raise
        return {"component":m["component"],"version":m["version"],"backup":str(backup),"files":len(files)}
def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest="command",required=True)
    b=sub.add_parser("build");b.add_argument("source",type=Path);b.add_argument("output",type=Path);b.add_argument("component",choices=sorted(COMPONENTS));b.add_argument("version");b.add_argument("--part-bytes",type=int,default=1500000000);b.add_argument("--require-base",default="0.2.0")
    i=sub.add_parser("install");i.add_argument("download",type=Path);i.add_argument("target",type=Path)
    a=p.parse_args()
    if a.command=="build":
        if a.part_bytes<1024:raise ValueError("Part size too small")
        print(build(a.source,a.output,a.component,a.version,a.part_bytes,{"base":a.require_base} if a.require_base else {}))
    else:print(json.dumps(install(a.download,a.target),ensure_ascii=False))
if __name__=="__main__":
    try:main()
    except (ValueError,OSError,KeyError,zipfile.BadZipFile) as e:
        print("Update not completed: "+str(e));raise SystemExit(1)





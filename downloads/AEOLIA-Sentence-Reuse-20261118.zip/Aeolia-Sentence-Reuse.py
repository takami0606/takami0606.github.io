"""Isolated, offline Marian sentence experiment. No product imports or mutations."""
import argparse
from collections import Counter
import html
import json
import os
import platform
from pathlib import Path
import re
import sys
import time
import unicodedata

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
DEFAULT_MODELS = str(ROOT / 'models')
ABBREVIATIONS = {'mr.', 'mrs.', 'ms.', 'dr.', 'prof.', 'e.g.', 'i.e.', 'etc.', 'vs.', 'no.', 'fig.'}

def segments(text):
    """Keep offsets; conservative heuristic, editable source is always retained."""
    result = []
    paragraph = 0
    for match in re.finditer(r'[^\r\n]+', text):
        line = match.group()
        if not line.strip():
            continue
        paragraph += 1
        start = 0
        for end in re.finditer(r'[。！？!?]+["\u201d\u2019」』)]*|\.+["\u201d\u2019」』)]*(?=\s|$)', line):
            boundary = end.end()
            fragment = line[start:boundary]
            word = fragment.strip().split()[-1].lower() if fragment.strip() else ''
            if word in ABBREVIATIONS or (re.fullmatch(r'(?:[a-z]\.)+', word) and word not in {'v.', 'a.', 'w.', 's.'}):
                continue
            if fragment.strip():
                a = start + len(fragment) - len(fragment.lstrip())
                b = boundary - len(fragment) + len(fragment.rstrip())
                result.append({'paragraph': paragraph, 'start': match.start()+a, 'end': match.start()+b, 'source': line[a:b]})
            start = boundary
        fragment = line[start:]
        if fragment.strip():
            a = start + len(fragment) - len(fragment.lstrip())
            b = len(line.rstrip())
            result.append({'paragraph': paragraph, 'start': match.start()+a, 'end': match.start()+b, 'source': line[a:b]})
    return result

def numbers(text):
    return Counter(re.findall(r'\d+(?:\.\d+)?', unicodedata.normalize('NFKC', text).replace(',', '')))

def identifiers(text):
    words = re.findall(r'(?<![A-Za-z0-9_-])[A-Za-z][A-Za-z0-9_-]*(?![A-Za-z0-9_-])', text)
    return Counter(w for w in words if '_' in w or '-' in w or any(c.isdigit() for c in w) or (len(w)>1 and w.isupper()) or re.search(r'[a-z][A-Z]', w))

def warnings(source, target):
    out = []
    if numbers(source) != numbers(target): out.append('NUMBERS_CHANGED: 表記変更も含む。人手確認')
    if identifiers(source) != identifiers(target): out.append('IDENTIFIERS_CHANGED: 識別子の欠落・改変・追加候補')
    if len(segments(source)) != len(segments(target)): out.append('SENTENCE_COUNT_CHANGED: 文数差。意味の抜けとは限らない')
    return out

class Backend:
    def __init__(self, model_root, threads=1):
        import ctranslate2
        import sentencepiece
        self.ct = ctranslate2
        self.sp = sentencepiece
        self.root = Path(model_root)
        self.threads = threads
        self.loaded = {}

    def load(self, direction):
        if direction in self.loaded: return 0.0
        start = time.perf_counter()
        path = self.root / direction
        cfg = json.loads((path/'tokenizer/tokenizer_config.json').read_text(encoding='utf-8'))
        if cfg.get('separate_vocabs') or cfg.get('clean_up_tokenization_spaces'):
            raise ValueError('Unsupported tokenizer configuration')
        vocab = json.loads((path/'tokenizer/vocab.json').read_text(encoding='utf-8'))
        if any(t.startswith('>>') for t in vocab): raise ValueError('Multilingual tokenizer not supported')
        source = self.sp.SentencePieceProcessor(model_proto=(path/'tokenizer/source.spm').read_bytes())
        target = self.sp.SentencePieceProcessor(model_proto=(path/'tokenizer/target.spm').read_bytes())
        translator = self.ct.Translator(str(path), device='cpu', compute_type='int8', inter_threads=1, intra_threads=self.threads)
        self.loaded[direction] = translator, source, target, vocab
        return time.perf_counter()-start

    def translate_one(self, text, direction):
        translator, source, target, vocab = self.loaded[direction]
        if any(t in text for t in ('</s>', '<unk>', '<pad>')):
            return {'target': '', 'status': 'UNPROCESSED_SPECIAL_TOKEN', 'warnings': []}
        pieces = source.encode(text.strip(), out_type=str)
        tokens = [p if p in vocab else '<unk>' for p in pieces] + ['</s>']
        if len(tokens) > 480:
            return {'target': '', 'status': 'UNPROCESSED_TOO_LONG', 'input_tokens': len(tokens), 'warnings': []}
        result = translator.translate_batch([tokens], beam_size=2, max_batch_size=1, max_input_length=0,
                    max_decoding_length=512, return_end_token=True)[0]
        hypothesis = result.hypotheses[0]
        output = target.decode([t for t in hypothesis if t not in {'</s>', '<pad>', '<unk>'}]).replace('\u2581', ' ').strip()
        flags = warnings(text, output)
        if '<unk>' in tokens: flags.append('UNKNOWN_INPUT_TOKEN')
        if '<unk>' in hypothesis: flags.append('UNKNOWN_OUTPUT_TOKEN')
        status = 'GENERATED_UNVERIFIED'
        if not hypothesis or hypothesis[-1] != '</s>': status = 'INCOMPLETE_OUTPUT'
        elif not output: status = 'EMPTY_OUTPUT'
        return {'target': output, 'status': status, 'input_tokens': len(tokens), 'warnings': flags}

def translate_document(backend, text, direction, mode='sentence'):
    units = segments(text) if mode == 'sentence' else ([{'paragraph': 0, 'start': 0, 'end': len(text), 'source': text}] if text.strip() else [])
    rows = []
    start = time.perf_counter()
    for i, unit in enumerate(units, 1):
        stamp = time.perf_counter()
        try: result = backend.translate_one(unit['source'], direction)
        except Exception as exc:
            result = {'target': '', 'status': 'UNPROCESSED_ERROR', 'warnings': [type(exc).__name__ + ': ' + str(exc)]}
        rows.append(dict(unit, index=i, seconds=time.perf_counter()-stamp, **result))
    return {'direction': direction, 'mode': mode, 'source': text, 'source_characters': len(text),
            'source_sentence_count_heuristic': len(segments(text)),
            'source_nonempty_lines': len([s for s in text.splitlines() if s.strip()]),
            'source_blank_lines': len([s for s in text.splitlines() if not s.strip()]),
            'seconds': time.perf_counter()-start, 'rows': rows}


# Standalone browser review UI. Existing app/model files are read only.
import ctypes, secrets, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs

def preflight(home):
    required=['runtime/python.exe']
    for direction in ['en-ja','ja-en']:
        required += ['models/'+direction+'/'+f for f in ['model.bin','config.json','shared_vocabulary.json','tokenizer/source.spm','tokenizer/target.spm','tokenizer/vocab.json','tokenizer/tokenizer_config.json']]
    missing=[str(home/f) for f in required if not (home/f).is_file()]
    for module in ['ctranslate2','sentencepiece']:
        folder=home/'runtime/Lib/site-packages'/module
        if not folder.is_dir():missing.append(str(folder)+' [required package folder]')
    if missing:raise RuntimeError('Required existing files are missing:\n'+'\n'.join(missing)+'\nNo files were installed or changed. Quality-only installs are not supported.')
    if Path(sys.executable).resolve() != (home/'runtime/python.exe').resolve():
        raise RuntimeError('Use the existing installation runtime/python.exe through Start-Reuse.cmd.')
    try:backend=Backend(home/'models',threads=1)
    except Exception as exc:raise RuntimeError('Existing ctranslate2/sentencepiece runtime cannot load: '+str(exc)+'\nExpected: '+str(home/'runtime/Lib/site-packages')+'\nNo automatic installation will be attempted.') from exc
    for direction in ['en-ja','ja-en']:
        backend.load(direction)
        result=backend.translate_one('Do not restart.' if direction=='en-ja' else '再起動してはならない。',direction)
        if result['status']!='GENERATED_UNVERIFIED':raise RuntimeError('Existing model failed startup test: '+direction+' '+result['status'])
    return backend

def page(token,source='',direction='en-ja',report=None,error=''):
    esc=html.escape
    options=''.join('<option value="'+d+'"'+(' selected' if d==direction else '')+'>'+d+'</option>' for d in ['en-ja','ja-en'])
    rows=''
    if report:
        rows='<p>翻訳時間 %.3f 秒 / %d 文（正確性未確認）</p>'%(report['seconds'],len(report['rows']))
        rows+='<table><tr><th>原文</th><th>訳文</th><th>状態・警告</th></tr>'
        for row in report['rows']:
            rows+='<tr><td>'+esc(row['source'])+'</td><td>'+esc(row['target'] or '【未処理／訳文なし】')+'</td><td>'+esc(row['status']+'\n'+'\n'.join(row['warnings']))+'</td></tr>'
        rows+='</table>'
    return '''<!doctype html><html lang="ja"><meta charset="utf-8"><title>AEOLIA 文単位実験・既存環境利用版</title>
<style>body{font:16px sans-serif;max-width:1200px;margin:24px auto;padding:16px;background:#f4f6fa;color:#18283b}textarea{width:100%;box-sizing:border-box;min-height:200px}button,select{padding:10px;margin:8px 8px 8px 0}table{width:100%;border-collapse:collapse;background:white}td,th{border:1px solid #bcc7d4;padding:12px;vertical-align:top;white-space:pre-wrap;overflow-wrap:anywhere}td{width:33%}.warning{color:#9b301a}pre{white-space:pre-wrap}</style>
<h1>AEOLIA 文単位翻訳・実験版</h1><p>既存モデルとPythonを読み取り利用。原文を自動置換・保存・外部送信しません。</p>
<p class="warning">精度未保証。「未満→以下」、否定・義務・条件の誤訳、識別子改変が残ります。警告なしでも必ず原文と照合してください。会社235Uの速度は未測定です。</p>
<p>翻訳中は完了まで待ってください。タブを閉じてもサーバーは止まりません。終了するには起動した黒い画面で Ctrl+C を押します。</p>
<form method="post" action="/translate"><input type="hidden" name="token" value="'''+esc(token)+'''"><label>方向 <select name="direction">'''+options+'''</select></label><br><label>原文（最大12,000文字）<textarea name="source" maxlength="12000" required>'''+esc(source)+'''</textarea></label><br><button type="submit">1文ずつ翻訳</button></form><pre class="warning">'''+esc(error)+'''</pre>'''+rows+'</html>'

def deny_outbound(event,args):
    if event in {'socket.connect','socket.getaddrinfo'}:raise PermissionError('Outbound connections disabled')

def main_reuse():
    for stream in [sys.stdout,sys.stderr]:
        if hasattr(stream,'reconfigure'):stream.reconfigure(encoding='utf-8')
    home=Path(os.environ.get('AEOLIA_HOME','')).resolve()
    if not os.environ.get('AEOLIA_HOME'):print('AEOLIA_HOME is missing. Run Start-Reuse.cmd.');return 2
    try:backend=preflight(home)
    except Exception as exc:print('STARTUP STOPPED\n'+str(exc));return 2
    print('Existing runtime and both models passed synthetic startup checks.',flush=True)
    if '--check' in sys.argv:backend.loaded.clear();return 0
    sys.addaudithook(deny_outbound)
    token=secrets.token_urlsafe(32)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def send(self,status,body):
            data=body.encode('utf-8');self.send_response(status)
            self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers();self.wfile.write(data)
        def do_GET(self):
            if self.headers.get('Host')!=self.server.authority or self.path!='/'+token:self.send(403,'Forbidden');return
            self.send(200,page(token))
        def do_POST(self):
            if self.path!='/translate' or self.headers.get('Host')!=self.server.authority or self.headers.get('Origin')!=self.server.origin:self.send(403,'Forbidden');return
            try:
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=150000:raise ValueError('Request size limit')
                if self.headers.get('Content-Type','').split(';')[0]!='application/x-www-form-urlencoded':raise ValueError('Form required')
                form=parse_qs(self.rfile.read(length).decode('utf-8'),max_num_fields=4)
                if not secrets.compare_digest(form.get('token',[''])[0],token):self.send(403,'Forbidden');return
                source=form.get('source',[''])[0];direction=form.get('direction',[''])[0]
                if not source.strip() or len(source)>12000 or direction not in ['en-ja','ja-en']:raise ValueError('Invalid source/direction; limit 12000 characters')
            except (ValueError,UnicodeError):self.send(400,'Invalid request. Go Back to preserve your input.');return
            try:self.send(200,page(token,source,direction,translate_document(backend,source,direction)))
            except Exception as exc:self.send(500,page(token,source,direction,error='翻訳処理エラー。原文を保持しました。'+type(exc).__name__))
    server=HTTPServer(('127.0.0.1',0),Handler)
    server.authority='127.0.0.1:'+str(server.server_port);server.origin='http://'+server.authority
    url=server.origin+'/'+token
    print(url,flush=True)
    print('Close with Ctrl+C in this window. No existing app settings are modified.',flush=True)
    if '--no-browser' not in sys.argv:ctypes.windll.shell32.ShellExecuteW(None,'open',url,None,None,1)
    try:server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt:pass
    finally:server.server_close();backend.loaded.clear()
    return 0
if __name__=='__main__':raise SystemExit(main_reuse())

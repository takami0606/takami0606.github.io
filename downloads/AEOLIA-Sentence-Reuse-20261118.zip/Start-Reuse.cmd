@echo off

setlocal

set "AEOLIA_HOME=%~1"

if not defined AEOLIA_HOME set /p "AEOLIA_HOME=Existing AEOLIA Translator folder (contains runtime and models): "

set "AEOLIA_HOME=%AEOLIA_HOME:"=%"

if not exist "%AEOLIA_HOME%\runtime\python.exe" (

  echo MISSING: "%AEOLIA_HOME%\runtime\python.exe"

  echo No changes made. This requires an already working lightweight installation.

  pause

  exit /b 2

)

set "PYTHONHOME="

set "PYTHONPATH="

set "PYTHONDONTWRITEBYTECODE=1"

"%AEOLIA_HOME%\runtime\python.exe" -I -B "%~dp0Aeolia-Sentence-Reuse.py"

if errorlevel 1 pause

